create definer = root@localhost trigger tg_addessay
    after insert
    on essay
    for each row
begin
insert into essayverify(aid) values(NEW.aid);
end;

