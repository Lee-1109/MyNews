create definer = root@localhost trigger tg_delete_essay
    after delete
    on essay
    for each row
begin
delete from essayverify ev where ev.aid=OLD.aid;
end;

